"""
run_all.py
==========
Convenience entry-point that runs both the PyRIT and Promptfoo passes
against the same agent YAML, producing two HTML reports.

Usage:
    python run_all.py                                # interactive picker
    python run_all.py --pf-techniques recommended    # curated set
    python run_all.py --pf-techniques all            # full 157x33 catalog
    python run_all.py --pf-framework owasp:llm       # one framework
    python run_all.py --pyrit-strategies GCG,CRESCENDO --pf-framework eu:ai-act
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import pyrit_module                                  # noqa: E402
import promptfoo_module                              # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Run PyRIT + Promptfoo passes back-to-back.")
    ap.add_argument("--config", type=Path,
                    default=ROOT / "conversation.yaml",
                    help="Agent YAML profile (default: ./conversation.yaml)")
    ap.add_argument("--reports-dir", type=Path,
                    default=ROOT / "reports",
                    help="Directory for HTML / JSON output (default: ./reports)")
    ap.add_argument("--pyrit-strategies", type=str, default=None,
                    help="Comma-separated PyRIT strategy codes "
                         "(default: all 17 strategies)")
    ap.add_argument("--pf-techniques", type=str, default=None,
                    help="Comma-separated Promptfoo technique IDs, or one of "
                         "'all' / 'plugins' / 'strategies' / 'recommended' / "
                         "<category name>")
    ap.add_argument("--pf-framework", type=str, default=None,
                    help="Expand a Promptfoo framework to its plugin set, "
                         "e.g. owasp:llm, owasp:api, owasp:agentic, "
                         "mitre:atlas, nist:ai:measure, dod, iso:42001, "
                         "gdpr, eu:ai-act")
    args = ap.parse_args()

    args.reports_dir.mkdir(parents=True, exist_ok=True)

    # ---- PyRIT --------------------------------------------------------
    if args.pyrit_strategies and args.pyrit_strategies.strip().lower() != "all":
        pyrit_sel = [s.strip() for s in args.pyrit_strategies.split(",")]
    else:
        pyrit_sel = None
    pyrit_module.run(
        config_path=args.config,
        output_html=args.reports_dir / "pyrit_report.html",
        strategies_filter=pyrit_sel,
    )

    # ---- Promptfoo ----------------------------------------------------
    if args.pf_framework:
        pf_sel = promptfoo_module.framework_plugin_ids(args.pf_framework)
        print(f"[run_all] Promptfoo framework '{args.pf_framework}' "
              f"expanded to {len(pf_sel)} plugins")
    elif args.pf_techniques:
        pf_sel = promptfoo_module._resolve_selection(args.pf_techniques)
    else:
        pf_sel = promptfoo_module._interactive_pick()

    promptfoo_module.run(
        config_path=args.config,
        output_html=args.reports_dir / "promptfoo_report.html",
        selected=pf_sel,
    )

    print("\n" + "=" * 60)
    print("Done. Reports:")
    print(f"  PyRIT     -> {args.reports_dir / 'pyrit_report.html'}")
    print(f"  Promptfoo -> {args.reports_dir / 'promptfoo_report.html'}")
    print("=" * 60)


if __name__ == "__main__":
    main()
