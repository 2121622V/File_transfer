"""
promptfoo_module/report_generator.py
------------------------------------
Renders the Promptfoo HTML report.

The report shows:
  - executive KPIs
  - coverage of plugins and strategies (with grey = not run)
  - failure rate by severity
  - failure rate by family (plugin vs strategy)
  - per-technique table
  - learning section: every technique with its example and rationale
  - detailed probe log
"""

from __future__ import annotations
import html
import json
from typing import Any, Dict, List


SEVERITY_COLOR = {
    "low":      "#10b981",
    "medium":   "#f59e0b",
    "high":     "#ef4444",
    "critical": "#7f1d1d",
}


def _esc(x: Any) -> str:
    return html.escape(str(x))


def _badge(text: str, color: str) -> str:
    return (f'<span style="background:{color};color:white;padding:2px 8px;'
            f'border-radius:12px;font-size:11px;font-weight:600;'
            f'text-transform:uppercase;letter-spacing:.5px;">'
            f'{_esc(text)}</span>')


def _pill(failed: bool) -> str:
    return _badge("FAIL" if failed else "PASS",
                  "#ef4444" if failed else "#10b981")


# ----------------------------------------------------------------------
def render_html(summary: Dict[str, Any]) -> str:
    results: List[dict] = summary["results"]
    metas:   List[dict] = summary["techniques_meta"]
    catalog: List[dict] = summary["all_techniques_catalog"]
    selected_ids = set(summary["techniques_selected"])

    # ---- per-technique aggregate --------------------------------------
    per_tech: Dict[str, dict] = {}
    for r in results:
        d = per_tech.setdefault(r["technique_id"], {
            "name": r["technique_name"],
            "family": r["family"],
            "category": r["category"],
            "severity": r["severity"],
            "total": 0, "failed": 0,
        })
        d["total"] += 1
        if r["failed_check"]:
            d["failed"] += 1

    # ---- KPI calculations ---------------------------------------------
    vr = summary["vulnerability_rate"] * 100
    vr_color = ("#10b981" if vr < 10
                else "#f59e0b" if vr < 30 else "#ef4444")
    cov = summary["coverage"]
    cov_pct = cov["coverage_pct"]

    real_badge = (_badge("real promptfoo cli", "#3b82f6")
                  if summary["real_promptfoo_used"]
                  else _badge("emulated", "#6b7280"))

    # ---- coverage matrix ----------------------------------------------
    def _coverage_section(items: List[dict], title: str) -> str:
        cells = ""
        for t in items:
            run = t["id"] in selected_ids
            d = per_tech.get(t["id"], {"total": 0, "failed": 0})
            if not run:
                bg = "#374151"; status = "not run"
            elif d["failed"] > 0:
                bg = SEVERITY_COLOR[t["severity"]]
                status = f'{d["failed"]}/{d["total"]} fail'
            else:
                bg = "#065f46"; status = f'{d["total"]} pass'
            cells += f"""
            <div style="background:{bg};padding:10px;border-radius:8px;
                        color:white;min-width:170px;flex:0 0 auto;">
                <div style="font-weight:600;font-size:12px;">
                    {_esc(t["name"])}</div>
                <div style="font-size:10px;opacity:.85;
                            font-family:ui-monospace,Menlo,monospace;
                            margin-top:2px;">{_esc(t["id"])}</div>
                <div style="font-size:11px;opacity:.85;margin-top:4px;">
                    {status}</div>
            </div>"""
        return f"""
        <h3 style="margin:18px 0 8px;color:#e5e7eb;font-size:14px;
                   text-transform:uppercase;letter-spacing:1px;">
            {_esc(title)}</h3>
        <div style="display:flex;flex-wrap:wrap;gap:10px;">{cells}</div>"""

    plugins  = [t for t in catalog if t["family"] == "plugin"]
    strats   = [t for t in catalog if t["family"] == "strategy"]
    cov_html = (_coverage_section(plugins,   "Plugins (vulnerabilities to test FOR)")
                + _coverage_section(strats,  "Strategies (delivery mechanisms)"))

    # ---- severity bars ------------------------------------------------
    sev_rows = ""
    for sev in ["low", "medium", "high", "critical"]:
        d = summary["by_severity"].get(sev)
        if not d:
            continue
        rate = (d["failed"] / d["total"] * 100) if d["total"] else 0
        sev_rows += f"""
        <div style="display:grid;grid-template-columns:90px 1fr 90px;
                    align-items:center;gap:12px;margin:8px 0;">
            <div>{_badge(sev, SEVERITY_COLOR[sev])}</div>
            <div style="background:#1f2937;border-radius:6px;height:24px;
                        position:relative;overflow:hidden;">
                <div style="background:{SEVERITY_COLOR[sev]};height:100%;
                            width:{rate:.1f}%;transition:width .8s;"></div>
            </div>
            <div style="text-align:right;font-weight:600;">
                {d['failed']}/{d['total']} ({rate:.0f}%)
            </div>
        </div>"""

    # ---- family bars --------------------------------------------------
    fam_rows = ""
    for fam in ["plugin", "strategy"]:
        d = summary["by_family"].get(fam)
        if not d:
            continue
        rate = (d["failed"] / d["total"] * 100) if d["total"] else 0
        fam_rows += f"""
        <div style="display:grid;grid-template-columns:120px 1fr 90px;
                    align-items:center;gap:12px;margin:8px 0;">
            <div>{_badge(fam, '#3b82f6' if fam=='plugin' else '#8b5cf6')}</div>
            <div style="background:#1f2937;border-radius:6px;height:24px;
                        position:relative;overflow:hidden;">
                <div style="background:#ef4444;height:100%;
                            width:{rate:.1f}%;transition:width .8s;"></div>
            </div>
            <div style="text-align:right;font-weight:600;">
                {d['failed']}/{d['total']} ({rate:.0f}%)
            </div>
        </div>"""

    # ---- per-technique table -----------------------------------------
    tech_rows = ""
    for tid, d in sorted(per_tech.items(),
                         key=lambda kv: -kv[1]["failed"]):
        rate = d["failed"] / d["total"] * 100 if d["total"] else 0
        col = "#ef4444" if d["failed"] else "#10b981"
        tech_rows += f"""
        <tr>
            <td><code style="font-size:11px;">{_esc(tid)}</code><br>
                <strong>{_esc(d["name"])}</strong>
                <div style="font-size:11px;color:#9ca3af;">
                    {_esc(d["category"])}</div></td>
            <td>{_badge(d["family"], '#3b82f6' if d["family"]=='plugin' else '#8b5cf6')}</td>
            <td>{_badge(d["severity"], SEVERITY_COLOR[d["severity"]])}</td>
            <td>{d["total"]}</td>
            <td style="color:{col};font-weight:600;">{d["failed"]}</td>
            <td>
                <div style="background:#1f2937;border-radius:4px;height:8px;
                            overflow:hidden;">
                    <div style="background:{col};height:100%;
                                width:{rate}%;"></div>
                </div>
                <small>{rate:.1f}%</small>
            </td>
        </tr>"""

    # ---- Technique reference (with examples) -------------------------
    def _ref_block(item: dict) -> str:
        ran = item["id"] in selected_ids
        return f"""
        <details {'open' if ran else ''} style="background:#1e293b;
            border:1px solid {'#3b82f6' if ran else '#334155'};
            border-radius:12px;padding:14px;margin:8px 0;">
          <summary style="cursor:pointer;font-weight:600;">
            {_badge(item["severity"], SEVERITY_COLOR[item["severity"]])}
            {_badge(item["family"], '#3b82f6' if item['family']=='plugin' else '#8b5cf6')}
            <strong>{_esc(item["name"])}</strong>
            <code style="margin-left:6px;">{_esc(item["id"])}</code>
            <span style="color:#9ca3af;font-size:12px;">
                · {_esc(item["category"])}
                {' · selected' if ran else ''}</span>
          </summary>
          <p style="color:#cbd5e1;margin:10px 0 4px;">
            {_esc(item["description"])}</p>
          <p style="margin:6px 0;"><strong style="color:#94a3b8;">
            Why it matters:</strong> {_esc(item["why_it_matters"])}</p>
          <p style="margin:6px 0 4px;"><strong style="color:#94a3b8;">
            Example prompt:</strong></p>
          <pre style="background:#0f172a;padding:12px;border-radius:8px;
                      white-space:pre-wrap;font-size:12px;
                      border-left:3px solid {SEVERITY_COLOR[item["severity"]]};">{_esc(item["example_prompt"])}</pre>
          {('<p style="font-size:11px;color:#9ca3af;">Requires Promptfoo&apos;s remote service.</p>'
            if item.get("requires_remote") else "")}
        </details>"""

    catalog_html = ("<h3 style='margin:18px 0 8px;color:#e5e7eb;font-size:14px;"
                    "text-transform:uppercase;letter-spacing:1px;'>"
                    f"Plugins ({len(plugins)})</h3>"
                    + "".join(_ref_block(t) for t in plugins)
                    + "<h3 style='margin:24px 0 8px;color:#e5e7eb;font-size:14px;"
                    "text-transform:uppercase;letter-spacing:1px;'>"
                    f"Strategies ({len(strats)})</h3>"
                    + "".join(_ref_block(t) for t in strats))

    # ---- detailed probe log ------------------------------------------
    detail_rows = ""
    for i, r in enumerate(results):
        prompt_disp = (r["prompt_sent"] if len(r["prompt_sent"]) < 220
                       else r["prompt_sent"][:220] + "…")
        detail_rows += f"""
        <tr>
            <td>{i+1}</td>
            <td><code>{_esc(r["technique_id"])}</code><br>
                <small>{_esc(r["technique_name"])}</small></td>
            <td>{_badge(r["severity"], SEVERITY_COLOR[r["severity"]])}</td>
            <td><pre style="margin:0;white-space:pre-wrap;
                font-family:ui-monospace,Menlo,monospace;font-size:11px;
                max-width:400px;">{_esc(prompt_disp)}</pre></td>
            <td><pre style="margin:0;white-space:pre-wrap;
                font-family:ui-monospace,Menlo,monospace;font-size:11px;
                max-width:400px;">{_esc(r["response"])}</pre></td>
            <td style="text-align:center;">{_pill(r["failed_check"])}</td>
            <td style="text-align:right;">{r["confidence"]:.2f}</td>
            <td style="text-align:right;color:#9ca3af;">{r["latency_ms"]}ms</td>
        </tr>"""

    # ---- final HTML --------------------------------------------------
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<title>Promptfoo Red-Team Report - {_esc(summary['agent'])}</title>
<style>
  * {{ box-sizing: border-box; }}
  body {{ margin: 0; font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, sans-serif;
         background:#0f172a;color:#e5e7eb; }}
  header {{ background:linear-gradient(135deg,#312e81,#0f172a);
            padding:32px 48px;border-bottom:1px solid #334155; }}
  h1 {{ margin:0 0 8px;font-size:28px; }}
  h2 {{ margin:32px 0 12px;font-size:18px;text-transform:uppercase;
        letter-spacing:1.5px;color:#94a3b8; }}
  main {{ padding:24px 48px 64px;max-width:1400px;margin:0 auto; }}
  .kpis {{ display:grid;
           grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
           gap:16px;margin:24px 0; }}
  .kpi {{ background:#1e293b;border-radius:12px;padding:18px;
          border:1px solid #334155; }}
  .kpi .v {{ font-size:32px;font-weight:700;line-height:1; }}
  .kpi .l {{ font-size:12px;color:#94a3b8;text-transform:uppercase;
             letter-spacing:1px;margin-top:8px; }}
  table {{ width:100%;border-collapse:collapse;background:#1e293b;
           border-radius:12px;overflow:hidden;
           border:1px solid #334155;font-size:13px; }}
  th, td {{ padding:10px 12px;text-align:left;
            border-bottom:1px solid #334155;vertical-align:top; }}
  th {{ background:#0f172a;font-size:11px;text-transform:uppercase;
        letter-spacing:1px;color:#94a3b8; }}
  tbody tr:hover {{ background:#243042; }}
  code {{ background:#0f172a;padding:2px 6px;border-radius:4px;
          font-family:ui-monospace,Menlo,monospace;font-size:11px; }}
</style>
</head>
<body>
<header>
  <h1>🛡️ Promptfoo Red-Team Report</h1>
  <div style="color:#cbd5e1;">
    Target: <strong>{_esc(summary['agent'])}</strong>
    v{_esc(summary['agent_version'])} &nbsp;·&nbsp;
    Generated {_esc(summary['timestamp'])} &nbsp;·&nbsp;
    {real_badge}
  </div>
</header>

<main>

  <!-- KPI cards -->
  <div class="kpis">
    <div class="kpi">
      <div class="v" style="color:{vr_color};">{vr:.1f}%</div>
      <div class="l">Vulnerability Rate</div>
    </div>
    <div class="kpi">
      <div class="v">{summary['vulnerabilities_found']}</div>
      <div class="l">Findings</div>
    </div>
    <div class="kpi">
      <div class="v">{summary['tests_executed']}</div>
      <div class="l">Probes Sent</div>
    </div>
    <div class="kpi">
      <div class="v">{cov['plugins_executed']}/{cov['total_plugins']}</div>
      <div class="l">Plugins Covered</div>
    </div>
    <div class="kpi">
      <div class="v">{cov['strategies_executed']}/{cov['total_strategies']}</div>
      <div class="l">Strategies Covered</div>
    </div>
    <div class="kpi">
      <div class="v" style="color:#3b82f6;">{cov_pct:.0f}%</div>
      <div class="l">Total Catalog Coverage</div>
    </div>
  </div>

  <!-- Severity & family bars -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
    <div>
      <h2>📊 By Severity</h2>
      <div style="background:#1e293b;padding:20px;border-radius:12px;
                  border:1px solid #334155;">
        {sev_rows or '<em>No data.</em>'}
      </div>
    </div>
    <div>
      <h2>🧬 By Family</h2>
      <div style="background:#1e293b;padding:20px;border-radius:12px;
                  border:1px solid #334155;">
        {fam_rows or '<em>No data.</em>'}
      </div>
    </div>
  </div>

  <!-- Coverage matrix -->
  <h2>🎯 Coverage Matrix</h2>
  <p style="color:#94a3b8;margin:0 0 12px;">
    Every Promptfoo technique. Coloured = executed (red/orange =
    findings; green = clean). Grey = not selected in this run.</p>
  {cov_html}

  <!-- Per technique -->
  <h2>📈 Per-Technique Results</h2>
  <table>
    <thead><tr>
      <th>Technique</th><th>Family</th><th>Severity</th>
      <th>Probes</th><th>Findings</th><th>Rate</th>
    </tr></thead>
    <tbody>{tech_rows}</tbody>
  </table>

  <!-- Catalog with examples -->
  <h2>📚 Technique Reference &amp; Examples</h2>
  <p style="color:#94a3b8;margin:0 0 8px;">
    All {len(catalog)} Promptfoo techniques. Selected techniques are
    expanded by default. Every entry includes the example prompt that
    Promptfoo would generate for this category.</p>
  {catalog_html}

  <!-- Detailed log -->
  <h2>🔬 Detailed Probe Log</h2>
  <table>
    <thead><tr>
      <th>#</th><th>Technique</th><th>Sev</th>
      <th>Prompt sent</th><th>Agent response</th>
      <th>Result</th><th>Conf.</th><th>Lat.</th>
    </tr></thead>
    <tbody>{detail_rows}</tbody>
  </table>

  <p style="color:#64748b;font-size:12px;margin-top:32px;text-align:center;">
    Report generated by Promptfoo Security Suite ·
    {_esc(summary['timestamp'])}
  </p>

</main>
</body>
</html>"""


if __name__ == "__main__":
    import sys
    if len(sys.argv) != 3:
        print("Usage: report_generator.py <results.json> <out.html>")
        sys.exit(1)
    with open(sys.argv[1]) as f:
        data = json.load(f)
    with open(sys.argv[2], "w") as f:
        f.write(render_html(data))
    print(f"Wrote {sys.argv[2]}")
