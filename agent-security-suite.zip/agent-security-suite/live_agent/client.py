"""
live_agent/client.py
--------------------
Thin client used by the security modules to talk to the live agent.

It tries the HTTP endpoint first; if the agent is not running it falls
back to importing `agent.respond` directly so the security pipeline
still produces results in fully offline environments.
"""

from __future__ import annotations

import json
import urllib.request
import urllib.error
from pathlib import Path
from typing import Optional

import yaml

ROOT = Path(__file__).resolve().parent


def load_agent_config(path: Optional[Path] = None) -> dict:
    path = path or (ROOT / "conversation.yaml")
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def _http_call(url: str, prompt: str, timeout: float = 5.0) -> Optional[str]:
    try:
        req = urllib.request.Request(
            url,
            data=json.dumps({"message": prompt}).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout) as r:
            payload = json.loads(r.read().decode("utf-8"))
            return payload.get("reply")
    except (urllib.error.URLError, TimeoutError, ConnectionError):
        return None


def _inproc_call(prompt: str) -> str:
    # Lazy import so this file works even if Flask isn't installed
    from agent import respond  # type: ignore
    return respond(prompt)


def ask(prompt: str, config: Optional[dict] = None) -> str:
    """Send `prompt` to the live agent and return the reply text."""
    config = config or load_agent_config()
    url = config["agent"]["endpoint"]["url"]
    reply = _http_call(url, prompt)
    if reply is not None:
        return reply
    # Fall back to in-process call
    try:
        return _inproc_call(prompt)
    except Exception as e:                              # pragma: no cover
        return f"[client-error] {e}"


if __name__ == "__main__":
    cfg = load_agent_config()
    print("Agent:", cfg["agent"]["name"])
    print("Try a prompt (Ctrl-C to quit):")
    while True:
        try:
            q = input("> ").strip()
            if not q:
                continue
            print(ask(q, cfg))
        except (KeyboardInterrupt, EOFError):
            print()
            break
