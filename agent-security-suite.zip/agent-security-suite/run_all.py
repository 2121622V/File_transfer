"""
run_all.py
----------
Convenience entry-point that runs both the PyRIT and Promptfoo passes
against the same agent YAML, producing both HTML reports.

Usage:
    python run_all.py                       # interactive Promptfoo picker
    python run_all.py --pf-techniques all   # everything, no prompts
    python run_all.py --pf-techniques recommended
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "pyrit_module"))
sys.path.insert(0, str(ROOT / "promptfoo_module"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", type=Path,
                    default=ROOT / "live_agent" / "conversation.yaml")
    ap.add_argument("--reports-dir", type=Path, default=ROOT / "reports")
    ap.add_argument("--pyrit-strategies", type=str, default=None,
                    help="Comma-separated PyRIT strategy codes "
                         "(default: all)")
    ap.add_argument("--pf-techniques", type=str, default=None,
                    help="Comma-separated Promptfoo technique IDs "
                         "(or 'all'/'plugins'/'strategies'/'recommended')")
    args = ap.parse_args()

    args.reports_dir.mkdir(parents=True, exist_ok=True)

    # ---- PyRIT --------------------------------------------------------
    import pyrit_runner                                   # type: ignore
    if args.pyrit_strategies is None or args.pyrit_strategies.strip().lower() == "all":
        pyrit_sel = None
    else:
        pyrit_sel = [s.strip() for s in args.pyrit_strategies.split(",")]
    pyrit_runner.run(
        config_path=args.config,
        output_html=args.reports_dir / "pyrit_report.html",
        strategies_filter=pyrit_sel,
    )

    # ---- Promptfoo ----------------------------------------------------
    import promptfoo_runner                               # type: ignore
    from techniques import ALL_TECHNIQUES, PLUGINS, STRATEGIES   # noqa: E402

    if args.pf_techniques:
        raw = args.pf_techniques.strip().lower()
        if raw == "all":
            sel = [t.id for t in ALL_TECHNIQUES]
        elif raw == "plugins":
            sel = [t.id for t in PLUGINS]
        elif raw == "strategies":
            sel = [t.id for t in STRATEGIES]
        elif raw == "recommended":
            sel = ["pii:direct", "prompt-extraction", "harmful:cybercrime",
                   "excessive-agency", "sql-injection",
                   "jailbreak", "prompt-injection", "base64",
                   "multilingual", "crescendo"]
        else:
            sel = [s.strip() for s in args.pf_techniques.split(",")]
    else:
        sel = promptfoo_runner._interactive_pick()

    promptfoo_runner.run(
        config_path=args.config,
        output_html=args.reports_dir / "promptfoo_report.html",
        selected=sel,
    )

    print("\n" + "=" * 60)
    print("Done. Reports:")
    print(f"  PyRIT     -> {args.reports_dir/'pyrit_report.html'}")
    print(f"  Promptfoo -> {args.reports_dir/'promptfoo_report.html'}")
    print("=" * 60)


if __name__ == "__main__":
    main()
