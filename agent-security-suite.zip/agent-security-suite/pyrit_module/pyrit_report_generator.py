"""
pyrit_module/report_generator.py
--------------------------------
Renders a self-contained HTML report from the JSON produced by
`pyrit_runner.py`. No external dependencies; all styling inline.
"""

from __future__ import annotations
import html
import json
from typing import Any, Dict, List


SEVERITY_COLOR = {
    "low":      "#10b981",
    "medium":   "#f59e0b",
    "high":     "#ef4444",
    "critical": "#7f1d1d",
}


def _esc(x: Any) -> str:
    return html.escape(str(x))


def _badge(text: str, color: str) -> str:
    return (f'<span style="background:{color};color:white;padding:2px 8px;'
            f'border-radius:12px;font-size:11px;font-weight:600;'
            f'text-transform:uppercase;letter-spacing:.5px;">{_esc(text)}</span>')


def _result_color(success: bool) -> str:
    return "#ef4444" if success else "#10b981"


def _result_pill(success: bool) -> str:
    return _badge("LEAK" if success else "BLOCKED",
                  _result_color(success))


# ----------------------------------------------------------------------
def render_html(summary: Dict[str, Any]) -> str:
    results: List[dict] = summary["results"]
    metas:   List[dict] = summary["strategies_meta"]
    sev_data: Dict[str, dict] = summary["by_severity"]

    # ---- aggregate per-strategy figures -------------------------------
    per_strat = {}
    for r in results:
        s = per_strat.setdefault(r["code"], {"total": 0, "success": 0,
                                              "name": r["name"],
                                              "severity": r["severity"],
                                              "category": r["category"]})
        s["total"] += 1
        if r["attack_success"]:
            s["success"] += 1

    # ---- coverage matrix cells ----------------------------------------
    category_groups: Dict[str, List[dict]] = {}
    for m in metas:
        category_groups.setdefault(m["category"], []).append(m)

    # ---- severity chart bars ------------------------------------------
    sev_order = ["low", "medium", "high", "critical"]
    sev_rows = ""
    for sev in sev_order:
        if sev not in sev_data:
            continue
        d = sev_data[sev]
        rate = (d["success"] / d["total"] * 100) if d["total"] else 0
        sev_rows += f"""
        <div style="display:grid;grid-template-columns:90px 1fr 80px;
                    align-items:center;gap:12px;margin:8px 0;">
            <div>{_badge(sev, SEVERITY_COLOR[sev])}</div>
            <div style="background:#1f2937;border-radius:6px;height:24px;
                        position:relative;overflow:hidden;">
                <div style="background:{SEVERITY_COLOR[sev]};height:100%;
                            width:{rate:.1f}%;transition:width .8s;"></div>
            </div>
            <div style="text-align:right;font-weight:600;">
                {d['success']}/{d['total']} ({rate:.0f}%)
            </div>
        </div>"""

    # ---- per-strategy rows --------------------------------------------
    strat_rows = ""
    for code, s in sorted(per_strat.items(),
                          key=lambda kv: -kv[1]["success"]):
        rate = s["success"] / s["total"] * 100 if s["total"] else 0
        strat_rows += f"""
        <tr>
            <td><strong>{_esc(s["name"])}</strong>
                <div style="font-size:11px;color:#9ca3af;">
                    {_esc(s["category"])}
                </div></td>
            <td>{_badge(s["severity"], SEVERITY_COLOR[s["severity"]])}</td>
            <td>{s["total"]}</td>
            <td style="color:{_result_color(s['success']>0)};font-weight:600;">
                {s["success"]}</td>
            <td>
                <div style="background:#1f2937;border-radius:4px;height:8px;
                            overflow:hidden;">
                    <div style="background:{_result_color(s['success']>0)};
                                height:100%;width:{rate}%;"></div>
                </div>
                <small>{rate:.1f}%</small>
            </td>
        </tr>"""

    # ---- coverage matrix HTML -----------------------------------------
    cov_html = ""
    for cat, items in category_groups.items():
        cells = ""
        for m in items:
            s = per_strat.get(m["code"], {"total": 0, "success": 0})
            bg = "#374151"
            label = "not run"
            if s["total"]:
                bg = (SEVERITY_COLOR[m["severity"]]
                      if s["success"] else "#065f46")
                label = (f'{s["success"]}/{s["total"]} leak'
                         if s["success"] else f'{s["total"]} blocked')
            cells += f"""
            <div style="background:{bg};padding:10px;border-radius:8px;
                        color:white;min-width:160px;">
                <div style="font-weight:600;font-size:13px;">
                    {_esc(m["name"])}</div>
                <div style="font-size:11px;opacity:.85;margin-top:4px;">
                    {label}</div>
            </div>"""
        cov_html += f"""
        <div style="margin:18px 0;">
            <h3 style="margin:0 0 8px;color:#e5e7eb;font-size:14px;
                       text-transform:uppercase;letter-spacing:1px;">
                {_esc(cat)}</h3>
            <div style="display:flex;flex-wrap:wrap;gap:10px;">
                {cells}
            </div>
        </div>"""

    # ---- detailed probe results ---------------------------------------
    detail_rows = ""
    for i, r in enumerate(results):
        prompt_disp = (r["prompt_sent"] if len(r["prompt_sent"]) < 200
                       else r["prompt_sent"][:200] + "…")
        detail_rows += f"""
        <tr>
            <td>{i+1}</td>
            <td><strong>{_esc(r["name"])}</strong></td>
            <td>{_badge(r["severity"], SEVERITY_COLOR[r["severity"]])}</td>
            <td><pre style="margin:0;white-space:pre-wrap;
                            font-family:ui-monospace,Menlo,monospace;
                            font-size:11px;max-width:380px;">{_esc(prompt_disp)}</pre></td>
            <td><pre style="margin:0;white-space:pre-wrap;
                            font-family:ui-monospace,Menlo,monospace;
                            font-size:11px;max-width:380px;">{_esc(r["response"])}</pre></td>
            <td style="text-align:center;">{_result_pill(r["attack_success"])}</td>
            <td style="text-align:right;">{r["confidence"]:.2f}</td>
            <td style="text-align:right;color:#9ca3af;">{r["latency_ms"]}ms</td>
        </tr>"""

    # ---- KPI cards ----------------------------------------------------
    asr_pct = summary["attack_success_rate"] * 100
    asr_color = ("#10b981" if asr_pct < 10
                 else "#f59e0b" if asr_pct < 30
                 else "#ef4444")
    cov_pct = summary["coverage"]["coverage_pct"]

    pyrit_badge = (_badge("real PyRIT", "#3b82f6")
                   if summary.get("pyrit_installed")
                   else _badge("emulated", "#6b7280"))

    # ---- assemble final HTML -----------------------------------------
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<title>PyRIT Security Report - {_esc(summary['agent'])}</title>
<style>
  * {{ box-sizing: border-box; }}
  body {{ margin: 0; font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, sans-serif;
         background: #0f172a; color: #e5e7eb; }}
  header {{ background: linear-gradient(135deg,#1e293b,#0f172a);
            padding: 32px 48px; border-bottom: 1px solid #334155; }}
  h1 {{ margin: 0 0 8px; font-size: 28px; }}
  h2 {{ margin: 32px 0 12px; font-size: 18px;
        text-transform: uppercase; letter-spacing: 1.5px; color: #94a3b8; }}
  main {{ padding: 24px 48px 64px; max-width: 1400px; margin: 0 auto; }}
  .kpis {{ display: grid;
           grid-template-columns: repeat(auto-fit, minmax(180px,1fr));
           gap: 16px; margin: 24px 0; }}
  .kpi {{ background:#1e293b;border-radius:12px;padding:18px;
          border:1px solid #334155; }}
  .kpi .v {{ font-size:32px;font-weight:700;line-height:1; }}
  .kpi .l {{ font-size:12px;color:#94a3b8;text-transform:uppercase;
             letter-spacing:1px;margin-top:8px; }}
  table {{ width:100%;border-collapse:collapse;background:#1e293b;
           border-radius:12px;overflow:hidden;
           border:1px solid #334155;font-size:13px; }}
  th, td {{ padding:10px 12px;text-align:left;
            border-bottom:1px solid #334155;vertical-align:top; }}
  th {{ background:#0f172a;font-size:11px;text-transform:uppercase;
        letter-spacing:1px;color:#94a3b8; }}
  tbody tr:hover {{ background:#243042; }}
  pre {{ background:transparent; }}
  details {{ background:#1e293b;border:1px solid #334155;
             border-radius:12px;padding:16px;margin:8px 0; }}
  summary {{ cursor:pointer;font-weight:600; }}
  code {{ background:#0f172a;padding:2px 6px;border-radius:4px;
          font-family:ui-monospace,Menlo,monospace;font-size:12px; }}
</style>
</head>
<body>
<header>
  <h1>🛡️ PyRIT Security Assessment</h1>
  <div style="color:#94a3b8;">
    Target: <strong>{_esc(summary['agent'])}</strong>
    v{_esc(summary['agent_version'])} &nbsp;·&nbsp;
    Generated {_esc(summary['timestamp'])} &nbsp;·&nbsp;
    {pyrit_badge}
  </div>
</header>

<main>

  <!-- KPI cards -->
  <div class="kpis">
    <div class="kpi">
      <div class="v" style="color:{asr_color};">{asr_pct:.1f}%</div>
      <div class="l">Attack Success Rate</div>
    </div>
    <div class="kpi">
      <div class="v">{summary['attacks_succeeded']}</div>
      <div class="l">Successful Attacks</div>
    </div>
    <div class="kpi">
      <div class="v">{summary['tests_executed']}</div>
      <div class="l">Probes Executed</div>
    </div>
    <div class="kpi">
      <div class="v">{summary['strategies_run']}</div>
      <div class="l">Strategies Used</div>
    </div>
    <div class="kpi">
      <div class="v" style="color:#3b82f6;">{cov_pct:.0f}%</div>
      <div class="l">Catalog Coverage</div>
    </div>
  </div>

  <!-- Severity chart -->
  <h2>📊 Success Rate by Severity</h2>
  <div style="background:#1e293b;padding:20px;border-radius:12px;
              border:1px solid #334155;">
    {sev_rows or '<em>No severity data.</em>'}
  </div>

  <!-- Coverage matrix -->
  <h2>🎯 Coverage Matrix</h2>
  <p style="color:#94a3b8;margin:0 0 12px;">
    Every strategy in the PyRIT catalog grouped by category. Red/orange =
    leak detected, green = blocked, grey = not executed.</p>
  {cov_html}

  <!-- Per strategy table -->
  <h2>📈 Per-Strategy Results</h2>
  <table>
    <thead><tr>
      <th>Strategy</th><th>Severity</th><th>Probes</th>
      <th>Leaks</th><th>Rate</th>
    </tr></thead>
    <tbody>{strat_rows}</tbody>
  </table>

  <!-- Strategies reference -->
  <h2>📚 Strategy Reference</h2>
  {''.join(
      f'<details><summary>{_badge(m["severity"], SEVERITY_COLOR[m["severity"]])} '
      f'<strong>{_esc(m["name"])}</strong> '
      f'<code>{_esc(m["code"])}</code> &nbsp;·&nbsp; '
      f'<span style="color:#94a3b8;">{_esc(m["category"])}</span></summary>'
      f'<p style="color:#cbd5e1;margin:12px 0 8px;">{_esc(m["description"])}</p>'
      f'<p><strong style="color:#94a3b8;">PyRIT class:</strong> '
      f'<code>{_esc(m["pyrit_orchestrator"])}</code></p>'
      f'{("<p><strong style=color:#94a3b8;>Converters:</strong> "+", ".join(f"<code>{_esc(c)}</code>" for c in m["converters"])+"</p>") if m["converters"] else ""}'
      f'<p><strong style="color:#94a3b8;">Example prompt:</strong></p>'
      f'<pre style="background:#0f172a;padding:12px;border-radius:8px;'
      f'white-space:pre-wrap;font-size:12px;">{_esc(m["example_prompts"][0]) if m["example_prompts"] else ""}</pre>'
      f'</details>'
      for m in metas)}

  <!-- Probe-level detail -->
  <h2>🔬 Detailed Probe Log</h2>
  <table>
    <thead><tr>
      <th>#</th><th>Strategy</th><th>Sev</th>
      <th>Prompt sent</th><th>Agent response</th>
      <th>Result</th><th>Conf.</th><th>Lat.</th>
    </tr></thead>
    <tbody>{detail_rows}</tbody>
  </table>

  <p style="color:#64748b;font-size:12px;margin-top:32px;text-align:center;">
    Report generated by PyRIT Security Suite ·
    {_esc(summary['timestamp'])}
  </p>

</main>
</body>
</html>"""


# ----------------------------------------------------------------------
if __name__ == "__main__":
    # Allow standalone usage: python report_generator.py results.json out.html
    import sys
    if len(sys.argv) != 3:
        print("Usage: report_generator.py <results.json> <out.html>")
        sys.exit(1)
    with open(sys.argv[1]) as f:
        data = json.load(f)
    with open(sys.argv[2], "w") as f:
        f.write(render_html(data))
    print(f"Wrote {sys.argv[2]}")
