# Agent Security Testing Suite

A complete, runnable framework that probes an LLM agent for safety,
privacy, and abuse risks using **two industry-standard red-teaming
engines**:

| Module       | Engine          | Language | Coverage             |
|--------------|-----------------|----------|----------------------|
| `pyrit_module`     | Microsoft PyRIT     | Python  | 17 attack strategies                  |
| `promptfoo_module` | Promptfoo (Node.js) | Python + Node.js | 30+ techniques (plugins + strategies) |

Both modules consume the **same YAML profile** for the agent under test
(`live_agent/conversation.yaml`) and emit a **self-contained HTML
report** with full coverage.

---

## Quick start

```bash
# 1. Install Python deps
pip install -r requirements.txt

# 2. (Optional) start the live agent in another terminal
python live_agent/agent.py            # localhost:8080

# 3. Run everything
python run_all.py --pyrit-strategies all --pf-techniques recommended

# 4. Open the reports
open reports/pyrit_report.html
open reports/promptfoo_report.html
```

If you don't start the live agent, both modules transparently fall back
to importing the agent's `respond()` function in-process so you still
get a complete, deterministic report.

---

## Project layout

```
agent-security-suite/
├── live_agent/
│   ├── conversation.yaml      <-- single source of truth (read by both modules)
│   ├── agent.py               <-- Flask demo agent (ShopBot)
│   └── client.py              <-- HTTP/in-proc client
├── pyrit_module/
│   ├── attack_strategies.py        <-- PyRIT strategy catalog
│   ├── pyrit_runner.py             <-- main entry-point
│   ├── pyrit_report_generator.py   <-- HTML renderer
│   └── requirements.txt
├── promptfoo_module/
│   ├── techniques.py               <-- 52-entry technique catalog (31 plugins + 21 strategies)
│   ├── promptfoo_runner.py         <-- main entry-point (wraps Node.js)
│   ├── promptfoo_report_generator.py <-- HTML renderer
│   ├── promptfooconfig.yaml        <-- auto-generated, can also be run by `npx promptfoo`
│   └── requirements.txt
├── reports/                   <-- HTML + JSON output goes here
├── sample_outputs/            <-- pre-built example reports (so you can see the format before running)
├── run_all.py                 <-- master entry-point
└── README.md
```

---

## The live agent (demo)

`live_agent/conversation.yaml` describes **ShopBot**, a fictional
e-commerce customer-service assistant. It contains:

* `agent.system_prompt` - the rules the bot must uphold
* `agent.endpoint` - where to send probes (used by both red-team modules)
* `conversations` - sample chat history (lets attack generators learn tone)
* `test_targets` - ground-truth probes with expected refusals
* `risk_profile` - drives strategy prioritisation

`live_agent/agent.py` is a small Flask service that implements a
realistic — but intentionally imperfect — rule-based responder so you
can run the whole pipeline locally **with no API keys**. Replace
`respond()` with a real LLM call (OpenAI / Anthropic / Azure / local
model) when you're ready to test the real thing.

---

## PyRIT module

### What it does

For every strategy in `attack_strategies.STRATEGIES` and every test
probe in the agent YAML, the runner:

1. Applies any converters (Base64, ROT13, Leetspeak, Unicode confusables, ASCII art, Morse, multilingual, GCG suffix, …).
2. Sends the resulting prompt to the live agent.
3. Scores the response with a deterministic rule-based scorer (compatible with PyRIT's `Scorer` interface).
4. Aggregates by severity, category, and strategy.

If `pip install pyrit` is available, the real `pyrit` package is
imported and used for orchestration; otherwise the runner runs in a
**built-in emulation mode** that uses the exact same logic.

### Strategies covered

| Code             | Severity  | Description |
|------------------|-----------|-------------|
| `PROMPT_SEND`    | low       | Baseline direct prompt |
| `RED_TEAM`       | high      | Adversarial-LLM red team |
| `CRESCENDO`      | high      | Multi-turn escalation |
| `PAIR`           | high      | Iterative refinement |
| `TAP`            | critical  | Tree of Attacks with Pruning |
| `MANY_SHOT`      | medium    | In-context jailbreak |
| `SKELETON_KEY`   | high      | Policy-override universal jailbreak |
| `CONV_BASE64`    | medium    | Base64-encoded prompt |
| `CONV_ROT13`     | medium    | ROT13 cipher |
| `CONV_LEET`      | low       | Leetspeak |
| `CONV_UNICODE`   | medium    | Unicode confusables |
| `CONV_ASCII_ART` | medium    | ASCII-art smuggling |
| `CONV_MORSE`     | low       | Morse code |
| `CONV_TRANSLATE` | medium    | Multilingual translation |
| `CONV_VARIATION` | low       | Paraphrase variation |
| `GCG`            | critical  | GCG adversarial suffix |
| `INDIRECT_INJECT`| critical  | Indirect prompt injection |

### CLI

```bash
# list all strategies
python pyrit_module/pyrit_runner.py --list

# run everything
python pyrit_module/pyrit_runner.py

# run a subset
python pyrit_module/pyrit_runner.py --strategies GCG,CRESCENDO,CONV_BASE64
```

### Output

* `reports/pyrit_report.html` - interactive HTML report
* `reports/pyrit_report.json` - machine-readable results

The report contains: executive KPIs, coverage matrix, severity chart,
per-strategy table, full strategy reference, and a probe-by-probe log
with the prompt sent and the agent's reply.

---

## Promptfoo module

### What it does

`promptfoo_module/promptfoo_runner.py` is a Python wrapper around the
Node.js Promptfoo CLI. It:

1. Lets the user interactively pick which techniques to run from the
   31-item catalog (or accepts `--techniques all|plugins|strategies|recommended|<csv>`).
2. Generates a **real, valid** `promptfooconfig.yaml` that you can also
   run yourself with `npx promptfoo redteam run`.
3. If Node.js + `npx promptfoo@latest` are available, runs the actual
   Promptfoo CLI.
4. Always also runs a faithful Python emulation against the live agent
   so the HTML report is produced even on machines without Node.js.

### Techniques (31 total)

**Plugins — what to test FOR** (vulnerability categories):

`harmful:hate`, `harmful:violent-crime`, `harmful:self-harm`,
`harmful:sexual-content`, `harmful:cybercrime`, `harmful:weapons`,
`harmful:misinformation`, `harmful:specialized-advice`,
`pii:direct`, `pii:session`, `pii:social`, `pii:api-db`,
`contracts`, `excessive-agency`, `hallucination`, `overreliance`,
`politics`, `religion`, `competitors`, `imitation`, `prompt-extraction`,
`bias:gender`, `bias:race`, `bola`, `bfla`, `rbac`, `sql-injection`,
`shell-injection`, `ssrf`, `debug-access`, `divergent-repetition`.

**Strategies — HOW to deliver the test**:

`jailbreak`, `jailbreak:tree`, `jailbreak:composite`, `jailbreak:likert`,
`crescendo`, `multilingual`, `prompt-injection`,
`indirect-prompt-injection`, `base64`, `leetspeak`, `rot13`, `hex`,
`morse`, `camelcase`, `math-prompt`, `citation`, `gcg`, `best-of-n`,
`pliny`, `audio`, `image`.

### Interactive picker

```bash
python promptfoo_module/promptfoo_runner.py
```

Sample output:

```
PROMPTFOO TECHNIQUES CATALOG  (31 total)
...
Select techniques to run.
  - Enter comma-separated IDs (e.g. pii:direct,jailbreak,base64)
  - 'all'         = every technique
  - 'plugins'     = every plugin
  - 'strategies'  = every strategy
  - 'recommended' = a curated balanced set
Your choice: pii:direct,prompt-extraction,base64,jailbreak
```

### Browse the catalog with examples

```bash
python promptfoo_module/promptfoo_runner.py --examples
```

This prints every technique with its example prompt and the
"why-it-matters" rationale — useful when you're learning Promptfoo.

### Output

* `reports/promptfoo_report.html` - interactive HTML report with:
  * coverage of every technique in the catalog
  * which ones you selected
  * results for each selected technique
  * **every technique's example, expanded by default for the ones you ran** so the report is also a teaching tool
* `reports/promptfoo_report.json` - machine-readable
* `promptfoo_module/promptfooconfig.yaml` - real Promptfoo config you can hand to teammates

---

## Running both at once

```bash
python run_all.py --pyrit-strategies all --pf-techniques recommended
```

The script writes both HTML reports into `reports/` and prints the
paths. Open them in any browser - they have no external dependencies.

---

## Going live with the real engines

* **PyRIT** - `pip install pyrit azure-identity openai` then point
  `attack_strategies.STRATEGIES[*].pyrit_orchestrator` at your Azure
  OpenAI / Anthropic deployment. The runner already imports `pyrit` when
  available.
* **Promptfoo** - install Node.js 18+ (`brew install node` / `apt install
  nodejs npm`) and the runner will invoke `npx promptfoo@latest redteam
  run` automatically. No global install needed.

---

## License

This scaffold is provided as-is for demonstration. PyRIT is MIT
(© Microsoft). Promptfoo is MIT (© promptfoo.dev).
